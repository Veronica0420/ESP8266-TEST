#ifndef __DELAY_H__
#define __DELAY_H__

/*
**********************************************************************
*                         ͷ�ļ�����
**********************************************************************
*/
#include <intrins.h>			// for nop

/*
**********************************************************************
*                         ���غ궨��
**********************************************************************
*/



/*
**********************************************************************
*                         �ⲿ����ԭ������
**********************************************************************
*/
void delay5us(void);
void delay10us(void);
void delay15us(void);
void delay45us(void);
void delay70us(void);
void delay100us(void);
void delay300us(void);
void delay750us(void);
void delay1ms(void);
void delay5ms(void);
void delay8ms(void);
void delay10ms(void);
void delay300ms(void) ;
void delay500ms(void);
void delay750ms(void);




#endif
